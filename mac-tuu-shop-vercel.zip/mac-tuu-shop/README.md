# Mạc Tửu Shop

Website bán hàng React/Vite, sẵn sàng deploy lên Vercel.

## Chạy thử trên máy

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Deploy lên Vercel

1. Upload project này lên GitHub.
2. Vào Vercel, chọn Add New Project.
3. Import repository.
4. Framework chọn Vite.
5. Build Command: `npm run build`
6. Output Directory: `dist`
7. Bấm Deploy.
